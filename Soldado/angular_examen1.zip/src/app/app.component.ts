import { Component } from "@angular/core";
import ciudades from 'src/assets/json/ciudades.json';
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent {

  json: any = ciudades;

  arrpaises: string[] = [];
  arrprovincias: string[] = [];
  arrciudades: string[] = [];

  ngOnInit(): void {
    const paises: string[] = [];
    this.json.forEach((elemento: any) => {
      if(!paises.includes(elemento.pais)){
        
        paises.push(elemento.pais);
      }
    });
    this.arrpaises = paises;
    
  }
  
  obtenerProvincias() {
    const provincias: string[] = [];
    const pais = document.querySelector('.pais') as any;
    
    this.json.forEach((elemento: any) => {
      if(!provincias.includes(elemento.provincia) && elemento.pais == pais.value){
        provincias.push(elemento.provincia);
      }
    });
    this.arrprovincias = provincias;
    this.quitarMensaje();
    this.obtenerCiudades();
  }

  obtenerCiudades() {
    const ciudades: string[] = [];
    const provincia = document.querySelector('.provincia') as any;
    console.log(provincia.value);
    
    this.json.forEach((elemento: any) => {
      
      if(!ciudades.includes(elemento.ciudad) && elemento.provincia == provincia.value){
        
        ciudades.push(elemento.ciudad);
      }
    });
    this.arrciudades = ciudades;
    this.quitarMensaje();

  }

  mostrarMensaje() {
    const pais = document.querySelector('.pais') as any;
    const provincia = document.querySelector('.provincia') as any;
    const ciudad = document.querySelector('.ciudad') as any;
    const body = document.querySelector('body');
    const mensaje = document.querySelector('.mensaje') as any;
    mensaje.innerHTML=  `<p>Has nacido en ${pais.value}, provincia/estado de ${provincia.value}, en la ciudad de ${ciudad.value}</p>`;
  }

  quitarMensaje(){
    const mensaje = document.querySelector('.mensaje') as any;
    if(mensaje != null){
      mensaje.innerHTML = "";
    }
  }


}
